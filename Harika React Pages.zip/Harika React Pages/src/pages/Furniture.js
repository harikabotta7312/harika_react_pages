import React , {Component} from 'react';
import {Link} from 'react-router-dom';
class Furniture extends React.Component {
    render() {
        return (
            <div>
<div>
  {/* Slider Arae Start */}
  <div className="slider-area">
    <div className="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
      {/* Slider Single Item Start */}
      <div className="slider-height-10 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-26.jpg)'}}>
        <div className="container">
          <div className="slider-content-13 slider-animated-1 text-left">
            <span className="animated">GREAT PLACE. GREAT MIND.</span>
            <h1 className="animated">
              New Designer Furniture<br />
              <strong>Elite Collections!</strong>
            </h1>
            <a href="shop-4-column.html" className="shop-btn animated">SHOP NOW</a>
          </div>
        </div>
      </div>
      {/* Slider Single Item End */}
      {/* Slider Single Item Start */}
      <div className="slider-height-10 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-27.jpg)'}}>
        <div className="container">
          <div className="slider-content-13 slider-animated-1 text-left">
            <span className="animated">OUTDOOR &amp; INDOOR DESIGN</span>
            <h1 className="animated">
              New Collection<br />
              <strong>Home Relaxing Chair</strong>
            </h1>
            <a href="shop-4-column.html" className="shop-btn animated">SHOP NOW</a>
          </div>
        </div>
      </div>
      {/* Slider Single Item End */}
    </div>
  </div>
  {/* Slider Arae End */}
  {/* Category Area Start */}
  <section className="categorie-area categorie-area-2 ptb-100px">
    <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
          {/* Section Title */}
          <div className="section-title mt-res-sx-30px mt-res-md-30px underline-shape">
            <h2>Popular Categories</h2>
            <p>Add Popular Categories to weekly line up</p>
          </div>
          {/* Section Title */}
        </div>
      </div>
      {/* Category Slider Start */}
      <div className="category-slider-2 owl-carousel owl-nav-style-3">
        {/* Single item */}
        <div className="category-item">
          <div className="category-list">
            <div className="category-thumb">
              <Link to="/Furnitureshop">
                <img src="assets/images/product-image/furniture/1.jpg" alt />
              </Link>
            </div>
            <div className="desc-listcategoreis">
              <div className="name_categories">
                <h4>Home Furniture</h4>
              </div>
              <span className="number_product">17 Products</span>
              <a href="shop-4-column.html"> Shop Now <i className="ion-android-arrow-dropright-circle" /></a>
            </div>
          </div>
        </div>
        {/* Single item */}
        <div className="category-item">
          <div className="category-list">
            <div className="category-thumb">
              <Link to="/OfficeFurniture">
                <img src="assets/images/product-image/furniture/2.jpg" alt />
              </Link>
            </div>
            <div className="desc-listcategoreis">
              <div className="name_categories">
                <h4>Office Furniture</h4>
              </div>
              <span className="number_product">17 Products</span>
              <Link to="/OfficeFurniture"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
            </div>
          </div>
        </div>
        {/* Single item */}
        <div className="category-item">
          <div className="category-list">
            <div className="category-thumb">
            <Link to="/OutdoorFurniture">
                <img src="assets/images/product-image/furniture/3.jpg" alt />
              </Link>
            </div>
            <div className="desc-listcategoreis">
              <div className="name_categories">
                <h4>Outdoor Furniture</h4>
              </div>
              <span className="number_product">17 Products</span>
              <Link to="/OutdoorFurniture"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
            </div>
          </div>
        </div>
        {/* Single item */}
        <div className="category-item">
          <div className="category-list">
            <div className="category-thumb">
             <Link to="/IndoorLighting">
                <img src="assets/images/product-image/furniture/4.jpg" alt />
              </Link>
            </div>
            <div className="desc-listcategoreis">
              <div className="name_categories">
                <h4>Indoor Lighting</h4>
              </div>
              <span className="number_product">17 Products</span>
              <Link to="/IndoorLighting"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
            </div>
          </div>
        </div>
        {/* Single item */}
        <div className="category-item">
          <div className="category-list">
            <div className="category-thumb">
              <Link to="/WallClocks">
                <img src="assets/images/product-image/furniture/5.jpg" alt />
              </Link>
            </div>
            <div className="desc-listcategoreis">
              <div className="name_categories">
                <h4>Wall Clocks</h4>
              </div>
              <span className="number_product">17 Products</span>
              <Link to="WallClocks"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
            </div>
          </div>
        </div>
        {/* Single item */}
        <div className="category-item">
          <div className="category-list">
            <div className="category-thumb">
             <Link to="/Furnitureshop">
                <img src="assets/images/product-image/furniture/6.jpg" alt />
              </Link>
            </div>
            <div className="desc-listcategoreis">
              <div className="name_categories">
                <h4>Kitchen</h4>
              </div>
              <span className="number_product">17 Products</span>
              <a href="shop-4-column.html"> Shop Now <i className="ion-android-arrow-dropright-circle" /></a>
            </div>
          </div>
        </div>
        {/* Single item */}
      </div>
    </div>
  </section>
  {/* Category Area End  */}
  {/* Banner Area Start */}
  <div className="banner-3-area mt-0px mb-100px">
    <div className="container">
      <div className="row">
        <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
          <div className="banner-wrapper banner-box">
            <a href="shop-4-column.html"><img src="assets/images/banner-image/37.jpg" alt /></a>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div className="banner-wrapper banner-box">
            <a href="shop-4-column.html"><img src="assets/images/banner-image/38.jpg" alt /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Banner Area End */}
  {/* Recent Add Product Area Start */}
  <section className="recent-add-area mb-70px">
    <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
          {/* Section Title */}
          <div className="section-title underline-shape">
            <h2>New Arrivals</h2>
            <p>Add new products to weekly line up</p>
          </div>
          {/* Section Title */}
        </div>
      </div>
      {/* Recent Product slider Start */}
      <div className="best-sell-slider owl-carousel owl-nav-style-3">
        {/* Product Single Item */}
        <div className="product-inner-item">
          <article className="list-product mb-30px">
            <div className="img-block">
              <Link to="/SingleproductBarStool" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/8.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/8.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                    <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                    <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs text-center">
              <a className="inner-link" href="shop-4-column.html"><span>FURNITURE</span></a>
              <h2><Link to="/SingleproductBarStool" className="product-link">Armless cushioned chair</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€23.90</li>
                  <li className="current-price">€21.51</li>
                  <li className="discount-price">-10%</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <Link to="/SingleproductBarChair" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/15.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/15.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                    <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to="/SingleproductBarChair" className="product-link">bar chair</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€35.90</li>
                  <li className="current-price">€34.11</li>
                  <li className="discount-price">-5%</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Product Single Item */}
        <div className="product-inner-item">
          <article className="list-product mb-30px">
            <div className="img-block">
              <Link to="/Singleproductlightdecor1" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/10.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/9.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>Furniture</span></a>
              <h2><Link to="/Singleproductlightdecor1" className="product-link">light decor</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <Link to='/SingleproductSingleLegStool' className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/16.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/16.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to='/SingleproductSingleLegStool' className="product-link">Single leg stool</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Product Single Item */}
        <div className="product-inner-item">
          <article className="list-product mb-30px">
            <div className="img-block">
              <Link to="/Singleproductlightdecor2" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/9.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/9.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>light</span></a>
              <h2><Link to="/Singleproductlightdecor2" className="product-link">light decor</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€35.90</li>
                  <li className="current-price">€34.11</li>
                  <li className="discount-price">-5%</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <Link to='/SingleproductCushionedChair2' className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/17.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/17.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                    <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to="/SingleproductCushionedChair2" className="product-link">cushioned chair</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€35.90</li>
                  <li className="current-price">€34.11</li>
                  <li className="discount-price">-5%</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Product Single Item */}
        <div className="product-inner-item">
          <article className="list-product mb-30px">
            <div className="img-block">
              <Link to="/SingleproductCushionedChair" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/21.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/17.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to="/SingleproductCushionedChair" className="product-link">cushioned chair</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€11.90</li>
                  <li className="current-price">€10.12</li>
                  <li className="discount-price">-15%</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <Link to="/SingleproductArmlessMetalChair" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/18.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/18.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to="/SingleproductArmlessMetalChair" className="product-link">armless metal chair</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€19.90</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Product Single Item */}
        <div className="product-inner-item">
          <article className="list-product mb-30px">
            <div className="img-block">
              <Link to="/SingleproductHeavyCushionedChairXl" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/13.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/13.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to="/SingleproductHeavyCushionedChairXl" className="product-link">heavy cushioned chair xl size</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€11.90</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <Link to="/SingleproductBarStool" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/19.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/19.jpg" alt />
              </Link>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><Link to="/SingleproductBarStool" className="product-link">Bar stool</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€18.90</li>
                  <li className="current-price">€15.11</li>
                  <li className="discount-price">-20%</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Product Single Item */}
        <div className="product-inner-item">
          <article className="list-product mb-30px">
            <div className="img-block">
              <a href="single-product-wooden-stool.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/14.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/14.jpg" alt />
              </a>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><a href="single-product-wooden-stool.html" className="product-link">stool</a></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€18.90</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <a href="single-product-indoor light.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/furniture/20.jpg" alt />
                <img className="second-img" src="assets/images/product-image/furniture/20.jpg" alt />
              </a>
              <div className="add-to-link">
                <ul>
                  <li>
                  <Link to="/Cart" title="Add to Cart"><i className="ion-bag" /></Link>
                  </li>
                  <li>
                  <Link to="/Wishlist" title="wishlist"><i className="ion-android-favorite-outline" /></Link>
                  </li>
                  <li>
                  <Link to="/Compare" title="Compare"><i className="ion-ios-shuffle-strong" /></Link>
                  </li>
                  <li>
                    <a href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal"><i className="ion-ios-search-strong" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
              <h2><a href="single-product-indoor light.html" className="product-link">light decor</a></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€18.90</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
      </div>
      {/* Recent Area Slider End */}
    </div>
  </section>
  {/* Recent product area end */}
  {/* Blog area Start */}
  <section className="blog-area mb-30px">
    <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
          {/* Section title */}
          <div className="section-title underline-shape">
            <h2>Latest Blogs</h2>
            <p>Present posts in a best way to highlight interesting moments of your blog.</p>
          </div>
          {/* Section title */}
        </div>
      </div>
      {/* Blog Slider Start */}
      <div className="blog-slider-active owl-carousel owl-nav-style-3">
        {/* single item */}
        <article className="blog-post">
          <div className="blog-post-top">
            <div className="blog-img banner-wrapper">
              <a href="#"><img src="assets/images/blog-image/blog-16.jpg" alt /></a>
            </div>
            <a href="blog-grid-left-sidebar.html" className="blog-meta">Furniture</a>
          </div>
          <div className="blog-post-content">
            <h4 className="blog-post-heading"><a href="blog-single-left-sidebar.html">home goods: writing table</a></h4>
            <p className="blog-text">
              A writing table (French bureau plat) has a series of drawers directly under the surface of the table, to contain writing implements, so that it may serve as a desk. Antique versions have the usual divisions for the inkwell, the blotter and the sand or powder tray in one of the drawers, and a surface covered with leather or some other material less hostile to the quill or the fountain pen than simple hard wood.
            </p>
            <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
          </div>
        </article>
        {/* single item */}
        <article className="blog-post">
          <div className="blog-post-top">
            <div className="blog-img banner-wrapper">
              <a href="#"><img src="assets/images/blog-image/blog-13.jpg" alt /></a>
            </div>
            <a href="blog-grid-left-sidebar.html" className="blog-meta">Furniture</a>
          </div>
          <div className="blog-post-content">
            <h4 className="blog-post-heading"><a href="blog-single-left-sidebar.html">Work from home</a></h4>
            <p className="blog-text">
              A writing table (French bureau plat) has a series of drawers directly under the surface of the table, to contain writing implements, so that it may serve as a desk. Antique versions have the usual divisions for the inkwell, the blotter and the sand or powder tray in one of the drawers, and a surface covered with leather or some other material less hostile to the quill or the fountain pen than simple hard wood.
            </p>
            <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
          </div>
        </article>
        {/* single item */}
        <article className="blog-post">
          <div className="blog-post-top">
            <div className="blog-img banner-wrapper">
              <a href="#"><img src="assets/images/blog-image/blog-14.jpg" alt /></a>
            </div>
            <a href="blog-grid-left-sidebar.html" className="blog-meta">Furniture</a>
          </div>
          <div className="blog-post-content">
            <h4 className="blog-post-heading"><a href="blog-single-left-sidebar.html">man made wood</a></h4>
            <p className="blog-text">
              A writing table (French bureau plat) has a series of drawers directly under the surface of the table, to contain writing implements, so that it may serve as a desk. Antique versions have the usual divisions for the inkwell, the blotter and the sand or powder tray in one of the drawers, and a surface covered with leather or some other material less hostile to the quill or the fountain pen than simple hard wood.
            </p>
            <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
          </div>
        </article>
        {/* single item */}
        <article className="blog-post">
          <div className="blog-post-top">
            <div className="blog-img banner-wrapper">
              <a href="#"><img src="assets/images/blog-image/blog-15.jpg" alt /></a>
            </div>
            <a href="blog-grid-left-sidebar.html" className="blog-meta">Furniture</a>
          </div>
          <div className="blog-post-content">
            <h4 className="blog-post-heading"><a href="blog-single-left-sidebar.html">This is Foruth Post For XipBlog</a></h4>
            <p className="blog-text">
              Lorem Ipsum is simply dummy text of the printing and typeSettings industry. Lorem Ipsum has been the industrys ...
            </p>
            <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
          </div>
        </article>
        {/* single item */}
      </div>
      {/* Blog Slider Start */}
    </div>
  </section>
  {/* Blog Area End */}
</div>

            </div>
        );
    }
}
export default Furniture;
