import React , {Component} from 'react';
import {Link} from 'react-router-dom';
class OfficeFurniture extends React.Component {
  render() {
    return (
      <div>
        <div>
          {/* Breadcrumb Area start */}
          <section className="breadcrumb-area">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <div className="breadcrumb-content">
                    <h1 className="breadcrumb-hrading">Shop Page</h1>
                    <ul className="breadcrumb-links">
                      <li><a href="index.html">Home</a></li>
                      <li>Shop List</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* Breadcrumb Area End */}
          {/* Shop Category Area End */}
          <div className="shop-category-area">
            <div className="container">
              <div className="row">
                <div className="col-lg-12 col-md-12">
                  {/* Shop Top Area Start */}
                  <div className="shop-top-bar">
                    {/* Left Side start */}
                    <div className="shop-tab nav mb-res-sm-15">
                      <a href="#shop-1" data-toggle="tab">
                        <i className="fa fa-th show_grid" />
                      </a>
                      <a className="active" href="#shop-2" data-toggle="tab">
                        <i className="fa fa-list-ul" />
                      </a>
                      <p>There Are 17 Products.</p>
                    </div>
                    {/* Left Side End */}
                    {/* Right Side Start */}
                    <div className="select-shoing-wrap">
                      <div className="shot-product">
                        <p>Sort By:</p>
                      </div>
                      <div className="shop-select">
                        <select>
                          <option value>Sort by newness</option>
                          <option value>A to Z</option>
                          <option value> Z to A</option>
                          <option value>In stock</option>
                        </select>
                      </div>
                    </div>
                    {/* Right Side End */}
                  </div>
                  {/* Shop Top Area End */}
                  {/* Shop Bottom Area Start */}
                  <div className="shop-bottom-area mt-35">
                    {/* Shop Tab Content Start */}
                    <div className="tab-content jump">
                      {/* Tab One Start */}
                      <div id="shop-1" className="tab-pane">
                        <div className="row">
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/furniture-1.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/furniture-1.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted T..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€18.90</li>
                                    <li className="current-price">€34.21</li>
                                    <li className="discount-price">-5%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                    <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-2.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-15.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">New Balance Fresh Foam Ka..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€18.90</li>
                                    <li className="current-price">€15.12</li>
                                    <li className="discount-price">-20%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                    <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-3.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-4.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNER</span></a>
                                <h2><a href="single-product.html" className="product-link">Brixton Patrol All Terrain..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-5.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-5.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNER</span></a>
                                <h2><a href="single-product.html" className="product-link">Juicy Couture Tricot Logo S..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-6.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-6.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">New Balance Arishi Sport v1</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-7.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-8.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNAR</span></a>
                                <h2><a href="single-product.html" className="product-link">Fila Locker Room Varsit...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-9.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-9.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Water and Wind Resista..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-10.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-10.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">New Luxury Men's Slim Fi...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€29.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-11.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-12.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Originals Kaval Win...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€23.90</li>
                                    <li className="current-price">€21.51</li>
                                    <li className="discount-price">-10%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-13.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-3.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Brixton Patrol All Terra...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-14.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-14.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Madden by Steve Madden C...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€11.90</li>
                                    <li className="current-price">€10.12</li>
                                    <li className="discount-price">-15%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-15.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-2.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted T..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€35.90</li>
                                    <li className="current-price">€34.11</li>
                                    <li className="discount-price">-5%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted T..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€18.90</li>
                                    <li className="current-price">€34.21</li>
                                    <li className="discount-price">-5%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-2.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-15.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                <h2><a href="single-product.html" className="product-link">New Balance Fresh Foam Ka..</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price">€18.90</li>
                                    <li className="current-price">€15.12</li>
                                    <li className="discount-price">-20%</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-3.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-4.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNER</span></a>
                                <h2><a href="single-product.html" className="product-link">Brixton Patrol All Terra...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                          <div className="col-xl-3 col-md-4 col-sm-6">
                            <article className="list-product">
                              <div className="img-block">
                                <a href="single-product.html" className="thumbnail">
                                  <img className="first-img" src="assets/images/product-image/organic/product-5.jpg" alt />
                                  <img className="second-img" src="assets/images/product-image/organic/product-5.jpg" alt />
                                </a>
                                <div className="quick-view">
                                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                    <i className="ion-ios-search-strong" />
                                  </a>
                                </div>
                              </div>
                              <ul className="product-flag">
                                <li className="new">New</li>
                              </ul>
                              <div className="product-decs">
                                <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNER</span></a>
                                <h2><a href="single-product.html" className="product-link">Juicy Couture Tricot Log...</a></h2>
                                <div className="rating-product">
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                  <i className="ion-android-star" />
                                </div>
                                <div className="pricing-meta">
                                  <ul>
                                    <li className="old-price not-cut">€18.90</li>
                                  </ul>
                                </div>
                              </div>
                              <div className="add-to-link">
                                <ul>
                                  <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                  <li>
                                  <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                  </li>
                                  <li>
                                  <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                  </li>
                                </ul>
                              </div>
                            </article>
                          </div>
                        </div>
                      </div>
                      {/* Tab One End */}
                      {/* Tab Two Start */}
                      <div id="shop-2" className="tab-pane active">
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductSingleLegStool" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/3.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/3.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FURNITURE</span></a>
                                      <h2><Link to="/SingleproductSingleLegStool" className="product-link">Outdoor Stool</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€9.10</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>QUALITY VERIFIED AND WARRANTY PROTECTED</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>299 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                        <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductArmlessMetalChair" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/11.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/11.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FRUNITURES</span></a>
                                      <h2><Link to="/SingleproductArmlessMetalChair" className="product-link">OFFICE CHAIRS</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€18.90</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>BEST QUALITY.</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>300 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                        <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductArmlessMetalChair" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/13.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/13.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FURNITURES</span></a>
                                      <h2><Link to="/SingleproductArmlessMetalChair" className="product-link">COMPFY CHAIRS</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€18.90</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>HIGHT QUALITY</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>300 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                        <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/WallClocks" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/5.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/15.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>CLOCK</span></a>
                                      <h2><Link to="/WallClocks" className="product-link">CLOCK</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€18.90</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>GERMAN MADE</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>299 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                        <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductSingleLegStool" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/10.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/10.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>HOLDER</span></a>
                                      <h2><Link to="/SingleproductSingleLegStool" className="product-link">PHONE HOLDER</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price">€18.90</li>
                                          <li className="current-price">€15.12</li>
                                          <li className="discount-price">-20%</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        &gt;
                                      </div>
                                      <div className="in-stock">Availability: <span>298 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                        <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductSingleLegStool" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/19.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/19.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FURNITURE</span></a>
                                      <h2><Link to="/SingleproductSingleLegStool" className="product-link">STYLISH STOOLS</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€11.90</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>GOOD QUALITY</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>291 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                        <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductSingleLegStool" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/27.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/27.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>Furniture</span></a>
                                      <h2><Link to="/SingleproductSingleLegStool" className="product-link">SIDE TABLE</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star-half" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€11.90</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>HIGH QUALITY.</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>299 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                          <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                          <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/WallClocks" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/30.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/30.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FURNITURE</span></a>
                                      <h2><Link to="/WallClocks" className="product-link">CLOCK</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price">€19.90</li>
                                          <li className="current-price">€10.12</li>
                                          <li className="discount-price">-15%</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>BEST IN INDIA</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>299 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                          <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductArmlessMetalChair" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/22.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/22.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FURNITURE</span></a>
                                      <h2><Link to="/SingleproductArmlessMetalChair" className="product-link">CHAIR</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€29.00</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                        <p>MADE IN INDIA</p>
                                      </div>
                                      <div className="in-stock">Availability: <span>300 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                          <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                          <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="shop-list-wrap mb-30px scroll-zoom">
                          <div className="row list-product m-0px">
                            <div className="col-md-12">
                              <div className="row">
                                <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                  <div className="left-img">
                                    <div className="img-block">
                                      <Link to="/SingleproductArmlessMetalChair" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/furniture/7.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/furniture/7.jpg" alt />
                                      </Link>
                                      <div className="quick-view">
                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                          <i className="ion-ios-search-strong" />
                                        </a>
                                      </div>
                                    </div>
                                    <ul className="product-flag">
                                      <li className="new">New</li>
                                    </ul>
                                  </div>
                                </div>
                                <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                  <div className="product-desc-wrap">
                                    <div className="product-decs">
                                      <a className="inner-link" href="shop-4-column.html"><span>FURNITURE</span></a>
                                      <h2><Link to="/SingleproductArmlessMetalChair" className="product-link">CUSHION CHAIRS</Link></h2>
                                      <div className="rating-product">
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                        <i className="ion-android-star" />
                                      </div>
                                      <div className="pricing-meta">
                                        <ul>
                                          <li className="old-price not-cut">€29.00</li>
                                        </ul>
                                      </div>
                                      <div className="product-intro-info">
                                      </div>
                                      <div className="in-stock">Availability: <span>899 In Stock</span></div>
                                    </div>
                                    <div className="add-to-link">
                                      <ul>
                                        <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                        <li>
                                          <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                        </li>
                                        <li>
                                        <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Tab Two End */}
          {/* Shop Tab Content End */}
          {/*  Pagination Area Start */}
          <div className="pro-pagination-style text-center">
            <ul>
              <li>
                <a className="prev" href="#"><i className="ion-ios-arrow-left" /></a>
              </li>
              <li><a className="active" href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li>
                <a className="next" href="#"><i className="ion-ios-arrow-right" /></a>
              </li>
            </ul>
          </div>
          {/*  Pagination Area End */}
          {/* Shop Bottom Area End */}
          {/* Shop Category Area End */}
        </div>

      </div>
    );
  }
}
export default OfficeFurniture;