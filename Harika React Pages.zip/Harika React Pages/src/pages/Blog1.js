//import { react } from '@babel/types';
import React , {Component} from 'react';
import {Link} from 'react-router-dom';
class Blog1 extends React.Component{
    render(){
        return(
           <div>
<div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Blog Post</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Blog List Left Sidebar</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* Shop Category Area End */}
  <div className="shop-category-area">
    <div className="container">
      <div className="row">
        <div className="col-lg-9 order-lg-last col-md-12 order-md-first">
          <div className="row">
            <div className="col-lg-5 col-md-6">
              <div className="single-blog-post blog-grid-post">
                <div className="blog-post-media">
                  <div className="blog-image">
                    <a href="#"><img src="assets/images/blog-image/blog-20.jpg" alt="blog" /></a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-7 col-md-6 align-self-center align-items-center">
              <div className="blog-post-content-inner">
                <h4 className="blog-title"><a href="#">SCIENCE: Medical Chemistry</a></h4>
                <ul className="blog-page-meta">
                  <li>
                    <a href="#"><i className="ion-person" /> Ojas Jawale</a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-calendar" /> 12 June, 2021</a>
                  </li>
                </ul>
                <p>
                  Medicinal chemistry and pharmaceutical chemistry are disciplines at the intersection of chemistry, especially
                  2 synthetic organic chemistry, and pharmacology and various other biological specialties, where they are involved 
                  with design, chemical synthesis and development for market of pharmaceutical agents, or bio-active molecules (drugs).
                </p>
                <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
              </div>
            </div>
            {/* single blog post */}
          </div>
          <div className="row mt-50">
            <div className="col-lg-5 col-md-6">
              <div className="single-blog-post blog-grid-post">
                <div className="blog-post-media">
                  <div className="blog-gallery">
                    <div className="gallery-item">
                      <a href="#"><img src="assets/images/blog-image/blog-8.jpg" alt="blog" /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-7 col-md-6 align-self-center align-items-center">
              <div className="blog-post-content-inner">
                <h4 className="blog-title"><a href="#">Cosmetics: Makeup Essentials</a></h4>
                <ul className="blog-page-meta">
                  <li>
                    <a href="#"><i className="ion-person" /> Ram Thakare</a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-calendar" /> 13 June, 2021</a>
                  </li>
                </ul>
                <p>
                  Cosmetics are constituted from a mixture of chemical compounds derived from either natural sources or synthetically created ones.
                  Cosmetics designed for skin care can be used to cleanse, exfoliate and protect the skin, as well as replenishing it, through the 
                  of cleansers, toners, serums, moisturizers, and balms; cosmetics designed for more general personal care, such as shampoo and body
                  wash, can be used to cleanse the body; cosmetics designed to enhance one's appearance (makeup) can be used to conceal blemishes, 
                  enhance one's natural features (such as the eyebrows and eyelashes).
                </p>
                <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
              </div>
            </div>
            {/* single blog post */}
          </div>
          <div className="row mt-50">
            <div className="col-lg-5 col-md-6">
              <div className="single-blog-post blog-grid-post">
                <div className="blog-post-media">
                  <div className="blog-post-audio">
                    <iframe className="embed-responsive-item" width={500} height={260} allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/users/182537870&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true" />
                  </div>
                </div>
              </div>
            </div>
            {/* single blog post */}
            {/* single blog post */}
          </div>
          {/*  Pagination Area Start */}
          <div className="pro-pagination-style text-center">
            <ul>
              <li>
                <a className="prev" href="#"><i className="ion-ios-arrow-left" /></a>
              </li>
              <li><a className="active" href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li>
                <a className="next" href="#"><i className="ion-ios-arrow-right" /></a>
              </li>
            </ul>
          </div>
          {/*  Pagination Area End */}
        </div>
        {/* Sidebar Area Start */}
        <div className="col-lg-3 order-lg-first col-md-12 order-md-last mb-res-md-60px mb-res-sm-60px">
          <div className="left-sidebar">
            {/* Sidebar single item */}
            <div className="sidebar-widget">
              <div className="main-heading">
                <h2>Search</h2>
              </div>
              <div className="search-widget">
                <form action="#">
                  <input placeholder="Search entire store here ..." type="text" />
                  <button type="submit"><i className="ion-ios-search-strong" /></button>
                </form>
              </div>
            </div>
            {/* Sidebar single item */}
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Categories</h2>
              </div>
              <div className="category-post">
                <ul>
                  <li><a href="#">Dresses (20)</a></li>
                  <li><a href="#">Jackets &amp; Coats (9)</a></li>
                  <li><a href="#">Sweaters (5)</a></li>
                  <li><a href="#">Jeans (11)</a></li>
                  <li><a href="#">Blouses &amp; Shirts (3)</a></li>
                  <li><a href="#">Electronic Cigarettes (6)</a></li>
                  <li><a href="#">Bags &amp; Cases (4)</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Recent Post</h2>
              </div>
              <div className="recent-post-widget">
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is First Post For XipBlog </a></h5>
                    <span className="date">APRIL 24, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-2.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Secound Post For XipBlog </a></h5>
                    <span className="date">APRIL 25, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Third Post For XipBlog </a></h5>
                    <span className="date">APRIL 26, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side m-0px">
                    <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Fourth Post For XipBlog </a></h5>
                    <span className="date">APRIL 27, 2020</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Tag</h2>
              </div>
              <div className="sidebar-widget-tag">
                <ul>
                  <li><a href="#">Fresh Fruit</a></li>
                  <li><a href="#"> Fresh Vegetables</a></li>
                  <li><a href="#">Fresh Salad</a></li>
                  <li><a href="#"> Butter &amp; Eggs</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
          </div>
        </div>
        {/* Sidebar Area End */}
      </div>
    </div>
  </div>
  {/* Shop Category Area End */}
</div>

           </div>
        );
    }
}
export default Blog1;