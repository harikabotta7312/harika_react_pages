//import { react } from '@babel/types';
import React , {Component} from 'react';
import {Link} from 'react-router-dom';
class Blog2 extends React.Component{
    render(){
        return(
           <div>
<div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Blog Post</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Blog List Right Sidebar</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* Shop Category Area End */}
  <div className="shop-category-area">
    <div className="container">
      <div className="row">
        <div className="col-lg-9 col-md-12">
          <div className="row">
            <div className="col-lg-5 col-md-6">
              <div className="single-blog-post blog-grid-post">
                <div className="blog-post-media">
                  <div className="blog-image">
                    <a href="#"><img src="assets/images/blog-image/blog-15.jpg" alt="blog" /></a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-7 col-md-6 align-self-center align-items-center">
              <div className="blog-post-content-inner">
                <h4 className="blog-title"><a href="#">Home Goods: Writing Table</a></h4>
                <ul className="blog-page-meta">
                  <li>
                    <a href="#"><i className="ion-person" /> Sahil Sharma</a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-calendar" /> 14 June, 2021</a>
                  </li>
                </ul>
                <p>
                  A writing table (French bureau plat) has a series of drawers directly under the surface of the table, to contain writing 
                  implements, so that it may serve as a desk. Antique versions have the usual divisions for the inkwell, the blotter and the 
                  sand or powder tray in one of the drawers, and a surface covered with leather or some other material less hostile to the 
                  quill or the fountain pen than simple hard wood.
                </p>
                <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
              </div>
            </div>
            {/* single blog post */}
          </div>
          <div className="row mt-50">
            <div className="col-lg-5 col-md-6">
              <div className="single-blog-post blog-grid-post">
                <div className="blog-post-media">
                  <div className="blog-gallery">
                    <div className="gallery-item">
                      <a href="#"><img src="assets/images/blog-image/blog-17.jpg" alt="blog" /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-7 col-md-6 align-self-center align-items-center">
              <div className="blog-post-content-inner">
                <h4 className="blog-title"><a href="#">Chemist: Medicine</a></h4>
                <ul className="blog-page-meta">
                  <li>
                    <a href="#"><i className="ion-person" /> Saniya Chaudhari</a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-calendar" /> 15 June, 2021</a>
                  </li>
                </ul>
                <p>
                  Medicine is the science and practice of caring for a patient and managing the diagnosis, prognosis, 
                  prevention, treatment or palliation of their injury or disease. Medicine encompasses a variety of health 
                  care practices evolved to maintain and restore health by the prevention and treatment of illness.
                </p>
                <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
              </div>
            </div>
            {/* single blog post */}
            {/* single blog post */}
            {/* single blog post */}
          </div>
          {/* single blog post */}
          <div className="row mt-50">
            <div className="col-lg-5 col-md-6">
              <div className="single-blog-post blog-grid-post">
                <div className="blog-post-media">
                  <div className="blog-image">
                    <a href="#"><img src="assets/images/blog-image/blog-6.jpg" alt="blog" /></a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-7 col-md-6 align-self-center align-items-center">
              <div className="blog-post-content-inner">
                <h4 className="blog-title"><a href="#">Essentials: Skin Products</a></h4>
                <ul className="blog-page-meta">
                  <li>
                    <a href="#"><i className="ion-person" /> Max Smith</a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-calendar" /> 16 June, 2021</a>
                  </li>
                </ul>
                <p>
                  Skin care is the range of practices that support skin integrity, enhance its appearance and relieve skin 
                  conditions. They can include nutrition, avoidance of excessive sun exposure and appropriate use of emollients. 
                  Practices that enhance appearance include the use of cosmetics, botulinum, exfoliation, fillers,
                  laser resurfacing, microdermabrasion, peels, retinol therapy.
                </p>
                <a className="read-more-btn" href="blog-single-left-sidebar.html"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
              </div>
            </div>
            {/* single blog post */}
          </div>
          {/*  Pagination Area Start */}
          <div className="pro-pagination-style text-center">
            <ul>
              <li>
                <a className="prev" href="#"><i className="ion-ios-arrow-left" /></a>
              </li>
              <li><a className="active" href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li>
                <a className="next" href="#"><i className="ion-ios-arrow-right" /></a>
              </li>
            </ul>
          </div>
          {/*  Pagination Area End */}
        </div>
        {/* Sidebar Area Start */}
        <div className="col-lg-3 col-md-12 mb-res-md-60px mb-res-sm-60px">
          <div className="left-sidebar">
            {/* Sidebar single item */}
            <div className="sidebar-widget">
              <div className="main-heading">
                <h2>Search</h2>
              </div>
              <div className="search-widget">
                <form action="#">
                  <input placeholder="Search entire store here ..." type="text" />
                  <button type="submit"><i className="ion-ios-search-strong" /></button>
                </form>
              </div>
            </div>
            {/* Sidebar single item */}
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Categories</h2>
              </div>
              <div className="category-post">
                <ul>
                  <li><a href="#">Dresses (20)</a></li>
                  <li><a href="#">Jackets &amp; Coats (9)</a></li>
                  <li><a href="#">Sweaters (5)</a></li>
                  <li><a href="#">Jeans (11)</a></li>
                  <li><a href="#">Blouses &amp; Shirts (3)</a></li>
                  <li><a href="#">Electronic Cigarettes (6)</a></li>
                  <li><a href="#">Bags &amp; Cases (4)</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Recent Post</h2>
              </div>
              <div className="recent-post-widget">
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is First Post For XipBlog </a></h5>
                    <span className="date">APRIL 24, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-2.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Secound Post For XipBlog </a></h5>
                    <span className="date">APRIL 25, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Third Post For XipBlog </a></h5>
                    <span className="date">APRIL 26, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side m-0px">
                    <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Fourth Post For XipBlog </a></h5>
                    <span className="date">APRIL 27, 2020</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Tag</h2>
              </div>
              <div className="sidebar-widget-tag">
                <ul>
                  <li><a href="#">Fresh Fruit</a></li>
                  <li><a href="#"> Fresh Vegetables</a></li>
                  <li><a href="#">Fresh Salad</a></li>
                  <li><a href="#"> Butter &amp; Eggs</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
          </div>
        </div>
        {/* Sidebar Area End */}
      </div>
    </div>
  </div>
  {/* Shop Category Area End */}
</div>

           </div>
        );
    }
}
export default Blog2;