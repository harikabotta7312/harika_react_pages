import React , {Component} from 'react';
import {Link} from 'react-router-dom';
class Lights extends React.Component{
    render(){
        return(
           <div>
<div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Single Product Page</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Single Product Affiliate</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* Shop details Area start */}
  <section className="product-details-area mtb-60px">
    <div className="container">
      <div className="row">
        <div className="col-xl-6 col-lg-6 col-md-12">
          <div className="product-details-img product-details-tab">
            <div className="zoompro-wrap zoompro-2">
              <div className="zoompro-border zoompro-span">
                <img className="zoompro" src="assets/images/product-image/furniture/4.jpg" data-zoom-image="assets/images/product-image/organic/zoom/6.jpg" alt />
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-6 col-lg-6 col-md-12">
          <div className="product-details-content">
            <h2> Indoor lighting</h2>
            <p className="reference">Reference:<span>light</span></p>
            <div className="pro-details-rating-wrap">
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <span className="read-review"><a className="reviews" href="#">Read reviews (1)</a></span>
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€18.21</li>
              </ul>
            </div>
            <p>Widely Used : The string lights are IP44 Waterproof, allow you to use them both indoor and outdoor. However the power and controller are non-waterproof, please protect them well when using outdoor. The lights sets are specially designed for different kinds of occasions, such as Christmas, Valentine's Day, party, wedding, home, festival, holiday, restaurant, hotel, commercial building
              High Quality : The star curtain lights are made of 100% Copper Wire Material and never overheat no matter how long you have them on</p>
            <div className="pro-details-list">
              <ul>
                <li>- sold by furniturewala </li>
                <li>- chrome metal</li>
                <li>- Colour    Black</li>
              </ul>
            </div>
            <div className="pro-details-quality mt-0px">
              <div className="pro-details-cart btn-hover">
                <a href="#"> Buy Now </a>
              </div>
            </div>
            <div className="pro-details-wish-com">
              <div className="pro-details-wishlist">
                <Link to="/Wishlist"><i className="ion-android-favorite-outline" />Add to wishlist</Link>
              </div>
              <div className="pro-details-compare">
                <Link to="/Compare"><i className="ion-ios-shuffle-strong" />Add to compare</Link>
              </div>
            </div>
            <div className="pro-details-social-info">
              <span>Share</span>
              <div className="social-info">
                <ul>
                  <li>
                    <a href="#"><i className="ion-social-facebook" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-twitter" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-google" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-instagram" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="pro-details-policy">
              <ul>
                <li><img src="assets/images/icons/policy.png" alt /><span>Security Policy (Edit With Customer Reassurance Module)</span></li>
                <li><img src="assets/images/icons/policy-2.png" alt /><span>Delivery Policy (Edit With Customer Reassurance Module)</span></li>
                <li><img src="assets/images/icons/policy-3.png" alt /><span>Return Policy (Edit With Customer Reassurance Module)</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Shop details Area End */}
  {/* product details description area start */}
  <div className="description-review-area mb-60px">
    <div className="container">
      <div className="description-review-wrapper">
        <div className="description-review-topbar nav">
          <a data-toggle="tab" href="#des-details1">Description</a>
          <a className="active" data-toggle="tab" href="#des-details2">Product Details</a>
          <a data-toggle="tab" href="#des-details3">Reviews (2)</a>
        </div>
        <div className="tab-content description-review-bottom">
          <div id="des-details2" className="tab-pane active">
            <div className="product-anotherinfo-wrapper">
              <ul>
                <li><span>Weight</span> 150gm </li>
                <li><span>Dimensions</span> ‎7.8 x 7.8 x 11.8 Centimeters</li>
                <li><span>Material type</span>metal</li>
                <li><span>Brand</span>furniturewala ltd.</li>
              </ul>
            </div>
          </div>
          <div id="des-details1" className="tab-pane">
            <div className="product-description-wrapper">
              <p>Widely Used : The string lights are IP44 Waterproof, allow you to use them both indoor and outdoor. However the power and controller are non-waterproof, please protect them well when using outdoor. The lights sets are specially designed for different kinds of occasions, such as Christmas, Valentine's Day, party, wedding, home, festival, holiday, restaurant, hotel, commercial building
                High Quality : The star curtain lights are made of 100% Copper Wire Material and never overheat no matter how long you have them on
              </p>
            </div>
          </div>
          <div id="des-details3" className="tab-pane">
            <div className="row">
              <div className="col-lg-7">
                <div className="review-wrapper">
                  <div className="single-review">
                    <div className="review-img">
                      <img src="assets/images/testimonial-image/1.png" alt />
                    </div>
                    <div className="review-content">
                      <div className="review-top-wrap">
                        <div className="review-left">
                          <div className="review-name">
                            <h4>rahul jain</h4>
                          </div>
                          <div className="rating-product">
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                          </div>
                        </div>
                        <div className="review-left">
                          <a href="#">Reply</a>
                        </div>
                      </div>
                      <div className="review-bottom">
                        <p>
                          nice lighting.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="single-review child-review">
                    <div className="review-img">
                      <img src="assets/images/testimonial-image/2.png" alt />
                    </div>
                    <div className="review-content">
                      <div className="review-top-wrap">
                        <div className="review-left">
                          <div className="review-name">
                            <h4>kevin hart</h4>
                          </div>
                          <div className="rating-product">
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                            <i className="ion-android-star" />
                          </div>
                        </div>
                        <div className="review-left">
                          <a href="#">Reply</a>
                        </div>
                      </div>
                      <div className="review-bottom">
                        <p>awesome.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-5">
                <div className="ratting-form-wrapper pl-50">
                  <h3>Add a Review</h3>
                  <div className="ratting-form">
                    <form action="#">
                      <div className="star-box">
                        <span>Your rating:</span>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="rating-form-style mb-10">
                            <input placeholder="Name" type="text" />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="rating-form-style mb-10">
                            <input placeholder="Email" type="email" />
                          </div>
                        </div>
                        <div className="col-md-12">
                          <div className="rating-form-style form-submit">
                            <textarea name="Your Review" placeholder="Message" defaultValue={""} />
                            <input type="submit" defaultValue="Submit" />
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* product details description area end */}
  {/* Recent Add Product Area Start */}
  <section className="recent-add-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          {/* Section Title */}
          <div className="section-title">
          <h2>You Might Also Like</h2>
            <p>Add Related products to weekly line up</p>
          </div>
          {/* Section Title */}
        </div>
      </div>
      {/* Recent Product slider Start */}
      <div className="recent-product-slider owl-carousel owl-nav-style">
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <Link to="/Furnitureshop" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/furniture/1.jpg" alt />
              <img className="second-img" src="assets/images/product-image/furniture/1.jpg" alt />
            </Link>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
            <h2><Link to="/Furnitureshop" className="product-link">armed chair </Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price">€18.90</li>
                <li className="current-price">€15.12</li>
                <li className="discount-price">-20%</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
              <li>
                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <Link to="/Furnitureshop" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/furniture/4.jpg" alt />
              <img className="second-img" src="assets/images/product-image/furniture/4.jpg" alt />
            </Link>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
            <h2><Link to="/Furnitureshop" className="product-link">Indoor lighting</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€18.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
              <li>
              <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <Link to="/Furnitureshop" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/furniture/5.jpg" alt />
              <img className="second-img" src="assets/images/product-image/furniture/5.jpg" alt />
            </Link>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>watch</span></a>
            <h2><Link to="/Furnitureshop" className="product-link">Modern clock</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€18.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
              <li>
              <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <Link to="/Furnitureshop" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/furniture/12.jpg" alt />
              <img className="second-img" src="assets/images/product-image/furniture/12.jpg" alt />
            </Link>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
            <h2><Link to="/Furnitureshop" className="product-link">Cushioned armless chair</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€18.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
              <li>
              <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <Link to="/Furnitureshop" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/furniture/9.jpg" alt />
              <img className="second-img" src="assets/images/product-image/furniture/9.jpg" alt />
            </Link>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
            <h2><Link to="/Furnitureshop" className="product-link">Decor light</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€18.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
              <li>
              <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <Link to="/Furnitureshop" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/furniture/15.jpg" alt />
              <img className="second-img" src="assets/images/product-image/furniture/15.jpg" alt />
            </Link>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>furniture</span></a>
            <h2><Link to="/Furnitureshop" className="product-link">Bar Chair</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€18.21</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
              <li>
              <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
      </div>
      {/* Recent product slider end */}
    </div>
  </section>
  {/* Recent product area end */}
  {/* Recent Add Product Area Start */}
  {/* Recent product area end */}
</div>

           </div>
        );
    }
}
export default Lights;