import Footer from './pages/Footer';
import Header from './pages/Header';
import { BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import Furniture from './pages/Furniture';
import Login from './pages/Login';
import Appliences from './pages/Appliences';
import Lights from './pages/Lights';
import Blog1 from './pages/Blog1';
import Blog2 from './pages/Blog2';
import Checkout from './pages/Checkout';
import Furnitureshop from './pages/Furnitureshop';
import Singleproductlightdecor1 from './pages/Singleproductlightdecor1';
import Singleproductlightdecor2 from './pages/Singleproductlightdecor2';
import SingleproductArmlessCushionedChair from './pages/SingleproductArmlessCushionedChair';
import SingleproductCushionedChair from './pages/SingleproductCushionedChair';
import SingleproductHeavyCushionedChairXl from './pages/SingleproductHeavyCushionedChairXl';
import SingleproductBarChair from './pages/SingleproductBarChair';
import SingleproductSingleLegStool from './pages/SingleproductSingleLegStool';
import SingleproductCushionedChair2 from './pages/SingleproductCushionedChair2';
import SingleproductArmlessMetalChair from './pages/SingleproductArmlessMetalChair';
import SingleproductBarStool from './pages/SingleproductBarStool';
import OfficeFurniture from './pages/OfficeFurniture';
import OutdoorFurniture from './pages/OutdoorFurniture';
import IndoorLighting from './pages/IndoorLighting';
import WallClocks from './pages/WallClocks';
function App() {
  return (
   <div>
     <Router>
        <Header />
        <Switch>
          <Route exact path='/' component={Furniture}/>
          <Route path='/Login' component={Login}/>
          <Route path='/Applinces' component={Appliences}/>
          <Route path='/Lights' component={Lights}/>
          <Route path='/Blog1' component={Blog1}/>
          <Route path='/Blog2' component={Blog2}/>
          <Route path='/Checkout' component={Checkout}/>
          <Route path='/Furnitureshop' component={Furnitureshop}/>
          <Route path='/Singleproductlightdecor1' component={Singleproductlightdecor1}/>
          <Route path='/Singleproductlightdecor2' component={Singleproductlightdecor2}/>
          <Route path='/SingleproductArmlessCushionedChair' component={SingleproductArmlessCushionedChair}/>
          <Route path='/SingleproductCushionedChair' component={SingleproductCushionedChair}/>
          <Route path='/SingleproductHeavyCushionedChairXl'component={SingleproductHeavyCushionedChairXl}/>
          <Route path='/SingleproductBarChair' component={SingleproductBarChair}/>
          <Route path='/SingleproductSingleLegStool' component={SingleproductSingleLegStool}/>
          <Route path='/SingleproductCushionedChair2' component={SingleproductCushionedChair2}/>
          <Route path='/SingleproductArmlessMetalChair' component={SingleproductArmlessMetalChair}/>
          <Route path='/SingleproductBarStool' component={SingleproductBarStool}/>
          <Route path='/OfficeFurniture' component={OfficeFurniture}/>
          <Route path='/OutdoorFurniture' component={OutdoorFurniture}/>
          <Route path='/IndoorLighting' component={IndoorLighting}/>
          <Route path='/WallClocks' component={WallClocks}/>
        </Switch>
        <Footer />
     </Router> 
   </div>
  );
}

export default App;
